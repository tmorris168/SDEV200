import java.lang.reflect.Array;
import java.util.*;
import java.util.Scanner;
import java.util.random.*;
import java.util.Arrays;
import java.util.ArrayList;

public class CharCreate {
	//Variables
		String characterRole;
		String characterName;
		int strStat;
		int conStat;
		int aglStat;
		int intStat;
		int chaStat;
		int wizStat;
		int total;
		
		//constructor for main
		public CharCreate(){
	    }
		
		public CharCreate(String CharRole, String Charname, int STR, int AGL, int CON, int INT, int WIZ, int CHA) {
			this.characterRole = CharRole;
			this.characterName = Charname;
			this.strStat = STR;
			this.conStat = CON;
			this.aglStat = AGL;
			this.intStat = INT;
			this.chaStat = CHA;
			this.wizStat = WIZ;
		}
		
		
		//Set Character Name
		public String getCharacterName() {
			return characterName;
		}
		
		public void setCharactername(String charName) {
			characterName = charName;
		    }
		
		
		//Set Character Role (Class)
		public String getCharacterRole() {
			return characterRole;
		}
		
		public void setcharacterRole(String charRole) {
	        this.characterRole = charRole;
		}

		//Set Strength	 
		public int getSTR() {
		        return strStat;
		    } 
		
		public void setSTR(int strength) {
			strStat = strength;
	    }

		//Set Agility	 
		public int getAGL() {
			return aglStat;
		} 
			
		public void setAGL(int agility) {
			aglStat = agility;
		}
		
		//Set Constitution	 
		public int getCON() {
			return conStat;
		} 
				
		public void setCON(int constitution) {
			conStat = constitution;
			}
		
		//Set Intelligence	 
			public int getINT() {
			        return intStat;
			    } 
			
			public void setINT(int intelligence) {
				intStat = intelligence;
		    }

		//Set Charisma	 
			public int getCHA() {
				return chaStat;
			} 
				
			public void setCHA(int charisma) {
				chaStat = charisma;
			}
			
		//Set Wizardry	 
			public int getWIZ() {
				return wizStat;
			} 
					
			public void setWIZ(int wizardry) {
				wizStat = wizardry;
				}
		

		//Displays Results
			 public String toString() 
			    {
			        return "Name: " + this.characterName +"\nCharacter Role: " + this.characterRole + "\nSTR: " + this.strStat + "\nAGL: " 
			    + this.aglStat + "\nCON: "+ this.conStat + "\nINT: " + this.intStat + "\nWIZ: " + this.wizStat + "\nCHA: " + this.chaStat + "\nIf there is a 0, then thats the remaining scores.";
			    }

}
