import java.lang.reflect.Array;
import java.util.*;
import java.util.Scanner;
import java.util.random.*;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Set;

public class SheetGen {

	 
			public static void main(String[] args) {
				//variables
				CharCreate Character = new CharCreate();
				String characterName;
				String characterRole;
				int[] dices1 = new int[6];
				int strStat = 0;
		        int aglStat = 0;
		        int conStat = 0;
		        int intStat = 0;
		        int wizStat = 0;
		        int chaStat = 0;
		        
		        
		    	System.out.print("Your Die Rolls are as follows: ");
				//roll the dice
				for (int i=0;i<dices1.length;i++)
					
				{
					
					dices1[i] = (int)(((Math.random()*6)+1)*3);
					if (dices1[i] <= 3) {
						dices1[i] = (int)((Math.random()*6)+1)*3; //re-roll in case of 3
					}
					System.out.print(dices1[i]+" ");//display results
				}
		    	
			
			//Enter Name
			try {
			System.out.println("\nEnter your characters name: ");
	        Scanner S = new Scanner(System.in);
	        characterName = S.nextLine();
	        Character.setCharactername(characterName);
	        
			
			//Enter your Role (Class)
	        System.out.println("\nPlease choose your class from the options below: ");
	        System.out.println("\n---------");
	        System.out.println("\nCleric, Thief, Warrior, or Wizard");
	        characterRole = S.nextLine();
	      //Validates for characters' roles (class)
	        while(!characterRole.equals("Cleric") && !characterRole.equals("Thief") && !characterRole.equals("Warrior") && !characterRole.equals("Wizard") )
	        {
	            System.out.println("\nPlease pick a class from the available options: ");
	            characterRole = S.nextLine();
	        }
	        Character.setcharacterRole(characterRole);
	        
	        
	        
	        
	        //Enter your statistics
	        //Strength
	        System.out.println("Please enter your strength: ");
	        strStat = S.nextInt();
	        if  (strStat != dices1[0] && strStat != dices1[1] && strStat != dices1[2] && strStat != dices1[3] && strStat != dices1[4] && strStat != dices1[5]) {
	        	System.out.println("Your ability score needs to be one of your die rolls.");
	        	strStat = S.nextInt();
	        }
	        else {
	        Character.setSTR(strStat);
	        }
	        
	        
	        //Agility
	        System.out.println("Please enter your agility: ");
	        aglStat = S.nextInt();
	        if  (aglStat != dices1[0] && aglStat != dices1[1] && aglStat != dices1[2] && aglStat != dices1[3] && aglStat != dices1[4] && aglStat != dices1[5]) {
	        	System.out.println("Your ability score needs to be one of your die rolls.");
	        	aglStat = S.nextInt();
	        }
	        else if (aglStat == strStat) {
	        	System.out.println("You need to pick a ability score that has not been picked.");
	        }
	        else {
	        Character.setAGL(aglStat);
	        }
	        
	        
	        //Constitution
	        System.out.println("Please enter your constitution: ");
	        conStat = S.nextInt();
	        if  (conStat != dices1[0] && conStat != dices1[1] && conStat != dices1[2] && conStat != dices1[3] && conStat != dices1[4] && conStat != dices1[5]) {
	        	System.out.println("Your ability score needs to be one of your die rolls.");
	        	conStat = S.nextInt();
	        }
	        else if (conStat == aglStat && conStat == strStat ) {
	        	System.out.println("You need to pick a ability score that has not been picked.");
	        }
	        else {
	        Character.setCON(conStat);
	        }
	        
	        
	        //Intelligence
	        System.out.println("Please enter your intelligence: ");
	        intStat = S.nextInt();
	        if  (intStat != dices1[0] && intStat != dices1[1] && intStat != dices1[2] && intStat != dices1[3] && intStat != dices1[4] && intStat != dices1[5]) {
	        	System.out.println("Your ability score needs to be one of your die rolls.");
	        	intStat = S.nextInt();
	        }
	        else if (intStat == aglStat && intStat == strStat && intStat == conStat) {
	        	System.out.println("You need to pick a ability score that has not been picked.");
	        }
	        else {
	        Character.setINT(intStat);
	        }
	        
	        
	        //Wizard stat
	        System.out.println("Please enter your wizardry: ");
	        wizStat = S.nextInt();
	        if  (wizStat != dices1[0] && wizStat != dices1[1] && wizStat != dices1[2] && wizStat != dices1[3] && wizStat != dices1[4] && wizStat != dices1[5]) {
	        	System.out.println("Your ability score needs to be one of your die rolls.");
	        	wizStat = S.nextInt();
	        }
	        else if (wizStat == aglStat && wizStat == strStat && wizStat == conStat && wizStat == intStat) {
	        	System.out.println("You need to pick a ability score that has not been picked.");
	        }
	        else {
	        	Character.setWIZ(wizStat);
	        }
	        
	        
	        
	        
	        //Charisma
	        System.out.println("Please enter your charisma: ");
	        chaStat = S.nextInt();
	        if  (chaStat != dices1[0] && chaStat != dices1[1] && chaStat != dices1[2] && chaStat != dices1[3] && chaStat != dices1[4] && chaStat != dices1[5]) {
	        	System.out.println("Your ability score needs to be one of your die rolls.");
	        	chaStat = S.nextInt();
	        }
	        else if (chaStat == aglStat && chaStat == strStat && chaStat == conStat && chaStat == intStat && chaStat == wizStat) {
	        	System.out.println("You need to pick a ability score that has not been picked.");
	        }
	        else {
	        	Character.setCHA(chaStat);
	        }
	        
	        
	        
	        System.out.println(Character.toString());
			}
			
	    catch(Exception e)
	    {
	        System.out.println("Error caught");
	    }
				
	}
			
}
			
	
